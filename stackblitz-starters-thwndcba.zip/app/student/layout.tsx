'use client';

export default function StudentLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  function handleLogout() {
    sessionStorage.removeItem('user');
    window.location.href = '/login';
  }

  return (
    <div className="min-h-screen flex">
      <aside className="w-64 bg-gray-900 text-white p-6">
        <h1 className="text-2xl font-bold mb-8">EduOS</h1>

        <nav className="space-y-4">
          <p className="cursor-pointer hover:text-gray-300">Dashboard</p>
          <p className="cursor-pointer hover:text-gray-300">Subjects</p>
          <p className="cursor-pointer hover:text-gray-300">Homework</p>
          <p className="cursor-pointer hover:text-gray-300">Marks</p>
          <p className="cursor-pointer hover:text-gray-300">Attendance</p>
          <p className="cursor-pointer hover:text-gray-300">Resources</p>

          <button
            onClick={handleLogout}
            className="w-full text-left text-red-400 hover:text-red-300 mt-8"
          >
            Logout
          </button>
        </nav>
      </aside>

      <main className="flex-1 p-8 bg-gray-50">{children}</main>
    </div>
  );
}
