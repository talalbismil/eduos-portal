'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function StudentPage() {
  const router = useRouter();
  const [authorized, setAuthorized] = useState(false);

  useEffect(() => {
    const user = sessionStorage.getItem('user');

    if (!user) {
      router.replace('/login');
      return;
    }

    const currentUser = JSON.parse(user);

    if (currentUser.role !== 'student') {
      router.replace('/login');
      return;
    }

    setAuthorized(true);
  }, [router]);

  if (!authorized) {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-xl shadow">
        <h1 className="text-3xl font-bold">Good Morning 👋</h1>
        <p className="text-gray-600 mt-2">
          Welcome back to EduOS Student Portal
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white p-5 rounded-xl shadow">
          <h2 className="font-bold">Attendance</h2>
          <p className="text-3xl mt-3">96%</p>
        </div>

        <div className="bg-white p-5 rounded-xl shadow">
          <h2 className="font-bold">Latest Marks</h2>
          <p className="mt-3">Physics: 87%</p>
          <p>Chemistry: 91%</p>
          <p>Mathematics: 84%</p>
        </div>

        <div className="bg-white p-5 rounded-xl shadow">
          <h2 className="font-bold">Announcements</h2>
          <p className="mt-3">Physics test on Friday</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow">
        <h2 className="text-xl font-bold">Today's Homework</h2>
        <ul className="mt-4 space-y-2">
          <li>📘 Physics Chapter 4</li>
          <li>🧪 Chemistry Worksheet</li>
          <li>📐 Mathematics Practice Set</li>
        </ul>
      </div>
    </div>
  );
}
