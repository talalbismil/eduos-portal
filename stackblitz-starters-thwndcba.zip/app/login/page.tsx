'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { studentData } from '@/data/student';
import { teacherData } from '@/data/teacher';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Check student credentials
    const student = studentData.find(
      (s) => s.username === username && s.password === password
    );
    if (student) {
      sessionStorage.setItem(
        'user',
        JSON.stringify({
          role: 'student',
          username: student.username,
          name: student.name,
        })
      );
      router.push('/student');
      return;
    }

    // Check teacher credentials
    const teacher = teacherData.find(
      (t) => t.username === username && t.password === password
    );
    if (teacher) {
      sessionStorage.setItem(
        'user',
        JSON.stringify({
          role: 'teacher',
          username: teacher.username,
          name: teacher.name,
        })
      );
      router.push('/teacher');
      return;
    }

    setError('Invalid username or password');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full space-y-8 p-8 bg-white rounded-lg shadow-md">
        <div>
          <h1 className="text-3xl font-bold text-center text-gray-900">
            EduOS
          </h1>
          <h2 className="mt-6 text-center text-xl font-semibold text-gray-700">
            Sign in to your account
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleLogin}>
          <div className="space-y-4">
            <div>
              <label
                htmlFor="username"
                className="block text-sm font-medium text-gray-700"
              >
                Username
              </label>
              <input
                id="username"
                name="username"
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your username"
              />
            </div>
            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-gray-700"
              >
                Password
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter your password"
              />
            </div>
          </div>

          {error && (
            <div className="text-red-600 text-sm text-center bg-red-50 p-2 rounded">
              {error}
            </div>
          )}

          <div>
            <button
              type="submit"
              className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Sign in
            </button>
          </div>

          <div className="text-sm text-gray-500 text-center border-t pt-4">
            <p>Demo credentials:</p>
            <p className="mt-1">Student: username: student, password: 1234</p>
            <p>Teacher: username: teacher, password: 1234</p>
          </div>
        </form>
      </div>
    </div>
  );
}
