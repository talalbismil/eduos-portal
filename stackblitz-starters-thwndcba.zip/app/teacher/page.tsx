export default function TeacherDashboard() {
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800">Welcome Teacher!</h1>
      <p className="text-gray-600 mt-2">
        This is your dashboard. Start managing your classes here.
      </p>

      {/* Add some quick stats cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500">Total Students</h3>
          <p className="text-3xl font-bold">0</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500">Courses</h3>
          <p className="text-3xl font-bold">0</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-gray-500">Pending Assignments</h3>
          <p className="text-3xl font-bold">0</p>
        </div>
      </div>
    </div>
  );
}
